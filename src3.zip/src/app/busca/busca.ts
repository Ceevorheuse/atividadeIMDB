import { Component, inject } from '@angular/core';
import { FilmeService } from '../model/filme-service';

@Component({
  selector: 'app-busca',
  imports: [],
  templateUrl: './busca.html',
  styleUrl: './busca.css'
})
export class Busca {
  filmeService = inject(FilmeService)

  constructor() {
    this.buscarPorTitulo()
  }

  buscarPorTitulo() {
    this.filmeService.obterFilme('The Godfather').subscribe(
      filme => {
        console.log(filme)
      })
  }
}
