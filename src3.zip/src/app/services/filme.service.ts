import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class FilmeService {
  private baseUrl = 'https://www.omdbapi.com/';
  private apiKey = 'ded6dc34';

  constructor(private http: HttpClient) {}

  buscarPorTitulo(titulo: string): Observable<any> {
    return this.http.get(`${this.baseUrl}?apikey=${this.apiKey}&t=${encodeURIComponent(titulo)}`);
  }

  buscarListaPorTitulo(titulo: string): Observable<any> {
    return this.http.get(`${this.baseUrl}?apikey=${this.apiKey}&s=${encodeURIComponent(titulo)}&type=movie`);
  }
}