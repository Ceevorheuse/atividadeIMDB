import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true, // 👈 importante para componentes standalone
  imports: [RouterOutlet, RouterLink], // 👈 adicionado RouterLink
  templateUrl: './app.html',
  styleUrls: ['./app.css'] // 👈 corrigido de styleUrl → styleUrls
})
export class App {
  protected title = 'Filmes';
}
