export interface Filme {
    Title: string
    Year: string
    Genre: string
    Director: string
    Writer: string
    Actors: string
    Plot: string
    Language: string
    Country: string
    Poster: string
}