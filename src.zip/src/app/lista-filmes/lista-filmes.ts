import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FilmeService } from '../services/filme.service';

@Component({
  selector: 'app-lista-filmes',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './lista-filmes.html',
  styleUrls: ['./lista-filmes.css']
})
export class ListaFilmesComponent {
  form: FormGroup;
  filmes: any[] = [];
  loading = false;
  error = '';

  constructor(private fb: FormBuilder, private fs: FilmeService) {
    this.form = this.fb.group({
      titulo: ['', [Validators.required, Validators.minLength(2)]]
    });
  }

  buscarLista() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const titulo = this.form.get('titulo')?.value;
    this.loading = true;
    this.error = '';
    this.filmes = [];

    this.fs.buscarListaPorTitulo(titulo).subscribe({
      next: (res) => {
        if (res.Response === 'True') {
          this.filmes = res.Search || [];
        } else {
          this.error = 'Nenhum filme encontrado.';
        }
        this.loading = false;
      },
      error: () => {
        this.error = 'Erro ao buscar lista.';
        this.loading = false;
      }
    });
  }
}