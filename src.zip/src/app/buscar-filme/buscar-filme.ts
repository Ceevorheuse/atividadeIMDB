import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FilmeService } from '../services/filme.service';

@Component({
  selector: 'app-buscar-filme',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './buscar-filme.html',
  styleUrls: ['./buscar-filme.css']
})
export class BuscarFilmeComponent {
  form: FormGroup;
  filme: any = null;
  loading = false;
  error = '';

  constructor(private fb: FormBuilder, private fs: FilmeService) {
    this.form = this.fb.group({
      titulo: ['', [Validators.required, Validators.minLength(2)]]
    });
  }

  buscar() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const titulo = this.form.get('titulo')?.value;
    this.loading = true;
    this.error = '';
    this.filme = null;

    this.fs.buscarPorTitulo(titulo).subscribe({
      next: (res) => {
        if (res.Response === 'True') {
          this.filme = res;
        } else {
          this.error = 'Filme não encontrado.';
        }
        this.loading = false;
      },
      error: () => {
        this.error = 'Erro ao buscar filme.';
        this.loading = false;
      }
    });
  }
}