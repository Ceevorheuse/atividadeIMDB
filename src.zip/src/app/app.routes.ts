import { Routes } from '@angular/router';
import { BuscarFilmeComponent } from './buscar-filme/buscar-filme';
import { ListaFilmesComponent } from './lista-filmes/lista-filmes';

export const routes: Routes = [
  { path: '', redirectTo: 'filme', pathMatch: 'full' },
  { path: 'filme', component: BuscarFilmeComponent },
  { path: 'lista', component: ListaFilmesComponent }
];